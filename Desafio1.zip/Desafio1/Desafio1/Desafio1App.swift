//
//  Desafio1App.swift
//  Desafio1
//
//  Created by Turma02-25 on 19/03/25.
//

import SwiftUI

@main
struct Desafio1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
